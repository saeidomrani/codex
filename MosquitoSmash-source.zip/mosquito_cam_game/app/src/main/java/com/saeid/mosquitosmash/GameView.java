package com.saeid.mosquitosmash;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends View {
    private final Random random = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Mosquito> mosquitoes = new ArrayList<>();
    private final List<Pop> pops = new ArrayList<>();
    private final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 75);

    private long lastFrame = SystemClock.uptimeMillis();
    private int score = 0;
    private int misses = 0;
    private boolean initialized = false;

    public GameView(Context context) {
        super(context);
        setWillNotDraw(false);
        setFocusable(true);
        textPaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!initialized && w > 0 && h > 0) {
            initialized = true;
            for (int i = 0; i < 3; i++) mosquitoes.add(newMosquito(w, h, i));
        }
    }

    private Mosquito newMosquito(int w, int h, int seedOffset) {
        Mosquito m = new Mosquito();
        m.size = dp(34 + random.nextInt(20));
        m.x = dp(40) + random.nextFloat() * Math.max(1, w - dp(80));
        m.y = dp(120) + random.nextFloat() * Math.max(1, h - dp(220));
        float speed = dp(90 + random.nextInt(70) + Math.min(score * 2, 120));
        float angle = (float) (random.nextFloat() * Math.PI * 2.0);
        m.vx = (float) Math.cos(angle) * speed;
        m.vy = (float) Math.sin(angle) * speed;
        m.phase = random.nextFloat() * 10f + seedOffset;
        return m;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.035f, Math.max(0.001f, (now - lastFrame) / 1000f));
        lastFrame = now;

        if (!initialized) {
            postInvalidateOnAnimation();
            return;
        }

        updateMosquitoes(dt, getWidth(), getHeight());
        for (Mosquito m : mosquitoes) drawMosquito(canvas, m, now);
        drawPops(canvas, now);
        drawHud(canvas);

        postInvalidateOnAnimation();
    }

    private void updateMosquitoes(float dt, int w, int h) {
        float top = dp(95);
        float bottom = h - dp(60);
        for (Mosquito m : mosquitoes) {
            m.phase += dt * 5f;
            m.x += (m.vx + (float) Math.sin(m.phase * 1.7f) * dp(30)) * dt;
            m.y += (m.vy + (float) Math.cos(m.phase * 1.3f) * dp(24)) * dt;
            float r = m.size * 0.8f;
            if (m.x < r) { m.x = r; m.vx = Math.abs(m.vx); }
            if (m.x > w - r) { m.x = w - r; m.vx = -Math.abs(m.vx); }
            if (m.y < top + r) { m.y = top + r; m.vy = Math.abs(m.vy); }
            if (m.y > bottom - r) { m.y = bottom - r; m.vy = -Math.abs(m.vy); }
        }
    }

    private void drawHud(Canvas canvas) {
        float pad = dp(16);
        paint.setColor(0x99000000);
        canvas.drawRoundRect(new RectF(pad, pad, getWidth() - pad, dp(82)), dp(18), dp(18), paint);

        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(dp(26));
        textPaint.setColor(0xFFFFE45C);
        canvas.drawText("★  " + score, dp(30), dp(58), textPaint);

        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setTextSize(dp(20));
        textPaint.setColor(0xFFFFFFFF);
        canvas.drawText("پشه‌ها رو بزن!", getWidth() - dp(30), dp(55), textPaint);

        if (score == 0) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(dp(19));
            textPaint.setColor(0xEEFFFFFF);
            paint.setColor(0x77000000);
            float y = getHeight() - dp(82);
            canvas.drawRoundRect(new RectF(dp(30), y - dp(34), getWidth() - dp(30), y + dp(18)), dp(16), dp(16), paint);
            canvas.drawText("روی پشه‌ها ضربه بزن 👆", getWidth() / 2f, y, textPaint);
        }
    }

    private void drawMosquito(Canvas canvas, Mosquito m, long now) {
        canvas.save();
        float rot = (float) Math.toDegrees(Math.atan2(m.vy, m.vx)) + 90f;
        canvas.translate(m.x, m.y);
        canvas.rotate(rot);

        float s = m.size;
        float wing = 0.82f + 0.18f * (float) Math.sin(now / 55.0 + m.phase);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xAAE9F7FF);
        canvas.save();
        canvas.rotate(-28f * wing);
        canvas.drawOval(new RectF(-s * 0.90f, -s * 0.55f, -s * 0.08f, s * 0.05f), paint);
        canvas.restore();
        canvas.save();
        canvas.rotate(28f * wing);
        canvas.drawOval(new RectF(s * 0.08f, -s * 0.55f, s * 0.90f, s * 0.05f), paint);
        canvas.restore();

        paint.setStrokeWidth(Math.max(2f, s * 0.06f));
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0xFF202020);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 3; i++) {
                Path leg = new Path();
                leg.moveTo(side * s * 0.16f, -s * 0.02f + i * s * 0.25f);
                leg.lineTo(side * s * (0.55f + i * 0.06f), s * (0.12f + i * 0.17f));
                leg.lineTo(side * s * (0.80f + i * 0.05f), s * (0.36f + i * 0.15f));
                canvas.drawPath(leg, paint);
            }
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF30343A);
        canvas.drawOval(new RectF(-s * 0.20f, -s * 0.44f, s * 0.20f, s * 0.46f), paint);
        paint.setColor(0xFF111111);
        canvas.drawCircle(0, -s * 0.53f, s * 0.22f, paint);

        paint.setColor(0xFFFF4D4D);
        canvas.drawCircle(-s * 0.09f, -s * 0.57f, s * 0.055f, paint);
        canvas.drawCircle(s * 0.09f, -s * 0.57f, s * 0.055f, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, s * 0.05f));
        paint.setColor(0xFF191919);
        canvas.drawLine(0, -s * 0.70f, 0, -s * 1.10f, paint);
        canvas.restore();
    }

    private void drawPops(Canvas canvas, long now) {
        Iterator<Pop> it = pops.iterator();
        while (it.hasNext()) {
            Pop p = it.next();
            float age = (now - p.born) / 550f;
            if (age >= 1f) {
                it.remove();
                continue;
            }
            float radius = dp(16) + dp(45) * age;
            int alpha = (int) (255 * (1f - age));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(5));
            paint.setColor((alpha << 24) | 0x00FFE45C);
            canvas.drawCircle(p.x, p.y, radius, paint);

            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(dp(28 + 10 * age));
            textPaint.setColor((alpha << 24) | 0x00FFFFFF);
            canvas.drawText("★", p.x, p.y + dp(9), textPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() != MotionEvent.ACTION_DOWN) return true;
        float tx = event.getX();
        float ty = event.getY();
        Mosquito hit = null;
        float best = Float.MAX_VALUE;

        for (Mosquito m : mosquitoes) {
            float dx = tx - m.x;
            float dy = ty - m.y;
            float d2 = dx * dx + dy * dy;
            float hitRadius = m.size * 1.25f;
            if (d2 <= hitRadius * hitRadius && d2 < best) {
                best = d2;
                hit = m;
            }
        }

        if (hit != null) {
            score++;
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 90);
            Pop p = new Pop();
            p.x = hit.x;
            p.y = hit.y;
            p.born = SystemClock.uptimeMillis();
            pops.add(p);

            Mosquito replacement = newMosquito(getWidth(), getHeight(), score);
            hit.x = replacement.x;
            hit.y = replacement.y;
            hit.vx = replacement.vx;
            hit.vy = replacement.vy;
            hit.size = replacement.size;
            hit.phase = replacement.phase;

            int wanted = Math.min(6, 3 + score / 8);
            while (mosquitoes.size() < wanted) mosquitoes.add(newMosquito(getWidth(), getHeight(), mosquitoes.size()));
        } else {
            misses++;
            if (misses % 3 == 0) tone.startTone(ToneGenerator.TONE_PROP_NACK, 45);
        }
        return true;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onDetachedFromWindow() {
        tone.release();
        super.onDetachedFromWindow();
    }

    private static class Mosquito {
        float x, y, vx, vy, size, phase;
    }

    private static class Pop {
        float x, y;
        long born;
    }
}
